﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Microsoft.Silverlight.Testing")]
[assembly: AssemblyDescription("Unit Test Framework for Silverlight 2")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft Corporation")]
[assembly: AssemblyProduct("Microsoft.Silverlight.Testing")]
[assembly: AssemblyCopyright("Copyright © 2009 Microsoft Corporation")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: NeutralResourcesLanguage("en-US")]
[assembly: ComVisible(false)]
[assembly: Guid("381499df-272c-409d-81be-6f9086fe5640")]
[assembly: AssemblyVersion("2.0.5.0")]
[assembly: AssemblyFileVersion("3.0.30518.1412")]
