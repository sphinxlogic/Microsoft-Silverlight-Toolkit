﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;

// TODO: Consider implementing WorkItem support.
////namespace Microsoft.Silverlight.Testing.UnitTesting.Metadata.VisualStudio
////{
////    //public class WorkItem : IWorkItem
////    //{
////    //    string Data { get; } // VSTT uses an integer ID
////    //}
////}