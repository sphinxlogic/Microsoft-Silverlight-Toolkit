﻿' (c) Copyright Microsoft Corporation.
' This source is subject to the Microsoft Public License (Ms-PL).
' Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
' All other rights reserved.

Imports System
Imports System.Reflection
Imports System.Resources
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("System.Windows.Controls.Samples")> 
<Assembly: AssemblyDescription("Samples for System.Windows.Controls (VB)")> 
<Assembly: AssemblyConfiguration("")>
<Assembly: AssemblyCompany("Microsoft Corporation")>
<Assembly: AssemblyProduct("Microsoft® Silverlight™ Toolkit")>
<Assembly: AssemblyCopyright("© Microsoft Corporation 2009")>
<Assembly: AssemblyTrademark("")>
<Assembly: AssemblyCulture("")>
<Assembly: NeutralResourcesLanguage("en-US")>
<Assembly: ComVisible(false)>
<Assembly: Guid("931c57f5-d711-4358-93ff-0d98de7bf27d")>
<Assembly: AssemblyVersion("2.0.5.0")>
<Assembly: AssemblyFileVersion("2.0.21024.1839")>